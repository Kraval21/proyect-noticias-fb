#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generar_entregable.py — Four Bells · Inteligencia de mercado

Genera un HTML (selección, Entregable A o Entregable B) a partir de una plantilla
reemplazando ÚNICAMENTE el bloque de datos <script id="datos-reporte">.
El logo, las fuentes, el CSS y el JavaScript nunca pasan por el modelo: se copian
byte a byte de la plantilla, y el resultado se verifica antes de guardarse.

Uso (las plantillas se buscan junto a este script; "final" y "seleccion" son atajos):
  python3 generar_entregable.py --plantilla final --datos datos.json \
      --tipo A --salida /mnt/user-data/outputs/Noticias_Semana45_Reporte1_2026-11-02_A.html \
      [--historial "carpeta/*.html" ...]

  python3 generar_entregable.py --plantilla seleccion --datos seleccion.json \
      --salida /mnt/user-data/outputs/Seleccion_Semana45_Reporte1_2026-11-02.html

  python3 generar_entregable.py --plantilla final --verificar archivo.html

Si hay un error, NO se escribe ningún archivo y el código de salida es 1.
"""
import argparse, base64, glob, hashlib, json, os, re, struct, sys, unicodedata, zlib
from difflib import SequenceMatcher

# ---- Huellas oficiales (no cambiar salvo que cambie el logo o las fuentes de la marca) ----
LOGO_SHA256 = "1b24094a62ab8ea11ec6ccda101c5f0cc53157f073d22eddd821c661ee4cc800"
FUENTES_SHA256 = {
    "0c21cd27ca96b995808923d4830b2a350cc2e5e3a3553bb06af2817509bad856",  # Aspekta 300
    "37d402fdeff68484b7954b8e6465e60f980c4139445cf1246e66c4b89095b6a9",  # Aspekta 500
    "7ed5b8859dcda933f9bdf65c3b39344a29d73486132e0af2db9f2b62541cdd92",  # Aspekta 550
    "e0c7c0d14afa5ade22956a9be2649ef6febfab25b160372f4a0ed532ee0b23e3",  # Aspekta 650
}

CATEGORIAS = ["Acero", "Mineral de hierro", "Chatarra ferrosa", "Carbón coquizable", "Petróleo y derivados",
              "Gas natural y electricidad", "Fletes y logística", "Macroeconomía"]
REGIONES = ["China", "EE.UU.", "Turquía", "Sureste asiático", "MENA", "LATAM y el Caribe", "CIS", "UE", "Global"]
TEMAS = ["Oferta y demanda", "Producción", "Disponibilidad", "Inventarios", "Tendencias de precio",
         "Aranceles y acuerdos comerciales", "Políticas regionales (RD, CO, CR, PR)", "Eventos estacionales",
         "Macroeconomía y tipo de cambio", "Geopolítica y conflictos", "Fletes y logística",
         "Nuevos competidores y plantas"]
SECCIONES = {"A": ["acero", "baltic", "energia"], "B": ["acero", "futuros", "baltic", "energia", "bunker"]}

RE_BLOQUE = re.compile(r'(<script type="application/json" id="datos-reporte">\n)(.*?)(\n</script>)', re.S)
RE_LOGO = re.compile(r'<img class="logo" src="data:image/png;base64,([A-Za-z0-9+/=]+)"')
RE_FUENTE = re.compile(r'url\(data:font/woff2;base64,([A-Za-z0-9+/=]+)\)')
RE_ISO = re.compile(r'^\d{4}-\d{2}-\d{2}$')


def png_integro(b):
    """Recorre todos los bloques del PNG y comprueba CRC y que termine en IEND."""
    if b[:8] != b'\x89PNG\r\n\x1a\n':
        return False, "firma PNG inválida"
    i = 8
    while i < len(b):
        if i + 12 > len(b):
            return False, "PNG truncado (bloque incompleto)"
        ln = struct.unpack('>I', b[i:i + 4])[0]
        tipo = b[i + 4:i + 8]
        fin = i + 8 + ln + 4
        if fin > len(b):
            return False, "PNG truncado (datos incompletos)"
        crc = struct.unpack('>I', b[i + 8 + ln:fin])[0]
        if zlib.crc32(tipo + b[i + 8:i + 8 + ln]) & 0xffffffff != crc:
            return False, "PNG corrupto (CRC)"
        i = fin
        if tipo == b'IEND':
            return (i == len(b)), ("OK" if i == len(b) else "datos sobrantes tras IEND")
    return False, "PNG sin bloque final IEND (truncado)"


def sin_datos(html):
    return RE_BLOQUE.sub(lambda m: m.group(1) + m.group(3), html, count=1)


def verificar_integridad(html, plantilla):
    """El archivo debe ser idéntico a la plantilla salvo el bloque de datos; además logo y fuentes oficiales."""
    errs = []
    if not RE_BLOQUE.search(html):
        errs.append("No se encontró el bloque <script id=\"datos-reporte\">.")
        return errs
    m = RE_LOGO.search(html)
    if not m:
        errs.append("No se encontró el logo embebido (<img class=\"logo\" ...>).")
    else:
        try:
            raw = base64.b64decode(m.group(1), validate=True)
        except Exception as e:
            errs.append("El logo no es base64 válido: %s" % e)
            raw = b''
        if raw:
            ok, msg = png_integro(raw)
            if not ok:
                errs.append("LOGO DAÑADO: %s." % msg)
            if hashlib.sha256(raw).hexdigest() != LOGO_SHA256:
                errs.append("El logo NO coincide con el logo oficial de Four Bells (huella distinta).")
    fuentes = RE_FUENTE.findall(html)
    if len(fuentes) != 4:
        errs.append("Fuentes Aspekta incrustadas: se esperaban 4 y hay %d." % len(fuentes))
    else:
        hs = set()
        for f in fuentes:
            try:
                b = base64.b64decode(f, validate=True)
            except Exception:
                errs.append("Una fuente incrustada no es base64 válido.")
                continue
            if b[:4] != b'wOF2':
                errs.append("Una fuente incrustada no es WOFF2 válido.")
            hs.add(hashlib.sha256(b).hexdigest())
        if hs != FUENTES_SHA256:
            errs.append("Las fuentes incrustadas no coinciden con Aspekta oficial.")
    if sin_datos(html) != sin_datos(plantilla):
        errs.append("El archivo NO es idéntico a la plantilla fuera del bloque de datos "
                    "(se alteró diseño, código, logo o fuentes). Regenerar con este script.")
    return errs


def limpiar(s):
    s = unicodedata.normalize('NFKD', str(s).lower())
    s = ''.join(c for c in s if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9 ]+', ' ', s).split()


def norm_titulo(t):
    return ' '.join(limpiar(t))


def norm_url(u):
    u = (u or '').strip().lower()
    u = re.sub(r'[?#].*$', '', u)
    return u.rstrip('/')


def cargar_historial(patrones):
    previos = []
    for pat in patrones or []:
        for f in glob.glob(pat):
            try:
                h = open(f, encoding='utf-8').read()
                m = RE_BLOQUE.search(h)
                if not m:
                    continue
                d = json.loads(m.group(2))
                for lista, etiqueta in (("noticias", "publicada"), ("descartadas", "descartada")):
                    for n in d.get(lista, []) or []:
                        previos.append((etiqueta, f, n))
            except Exception:
                continue
    return previos


def validar_datos(d, modo, tipo, permitir_ejemplo, historial):
    errs, avisos = [], []
    meta = d.get("meta") or {}
    for k in ("semana", "reporte", "fecha"):
        if k not in meta:
            errs.append("meta.%s es obligatorio." % k)
    if not RE_ISO.match(str(meta.get("fecha", ""))):
        errs.append("meta.fecha debe tener formato AAAA-MM-DD.")
    if modo == "final":
        if meta.get("tipo") not in ("A", "B"):
            errs.append("meta.tipo debe ser \"A\" o \"B\" (usa --tipo).")
    else:
        if meta.get("tipo") != "SELECCION":
            errs.append("En el HTML de selección meta.tipo debe ser \"SELECCION\".")
    if not permitir_ejemplo and (meta.get("sello") or "").strip().lower().startswith("datos ilustrativos"):
        errs.append("meta.sello contiene \"Datos ilustrativos\": es el dato de ejemplo de la plantilla. Déjalo vacío.")
    v = meta.get("ventana")
    desde = hasta = None
    if v:
        desde, hasta = str(v.get("desde", ""))[:10], str(v.get("hasta", ""))[:10]
        if not (RE_ISO.match(desde) and RE_ISO.match(hasta)):
            errs.append("meta.ventana.desde/hasta deben empezar con AAAA-MM-DD.")
            desde = hasta = None
    else:
        avisos.append("meta.ventana no está definida: no se pudo validar el rango de fechas.")

    ns = d.get("noticias")
    if not isinstance(ns, list) or not ns:
        errs.append("noticias debe ser una lista con al menos una noticia.")
        ns = []
    numeros = []
    for i, n in enumerate(ns, 1):
        p = "Noticia #%s" % n.get("n", i)
        numeros.append(n.get("n"))
        for k in ("titulo", "fuente", "fecha", "url", "resumen", "impacto", "categorias", "regiones", "temas"):
            if not n.get(k):
                errs.append("%s: falta el campo \"%s\"." % (p, k))
        if n.get("fecha") and not RE_ISO.match(str(n["fecha"])):
            errs.append("%s: fecha debe ser AAAA-MM-DD." % p)
        elif desde and n.get("fecha") and not (desde <= n["fecha"] <= hasta):
            errs.append("%s: la fecha %s está FUERA de la ventana (%s a %s)." % (p, n["fecha"], desde, hasta))
        if n.get("url") and not re.match(r'^https?://', n["url"]):
            errs.append("%s: la URL debe empezar con http(s)://" % p)
        for campo, lista in (("categorias", CATEGORIAS), ("regiones", REGIONES), ("temas", TEMAS)):
            for val in n.get(campo, []) or []:
                if val not in lista:
                    errs.append("%s: %s \"%s\" no está en la lista controlada." % (p, campo[:-1] if campo != "temas" else "tema", val))
        if n.get("impacto") and len(n["impacto"].split()) > 20:
            errs.append("%s: el impacto tiene %d palabras (máximo 20)." % (p, len(n["impacto"].split())))
    if numeros and any(not isinstance(x, int) for x in numeros):
        errs.append("Todas las noticias deben tener número entero \"n\".")
    elif numeros:
        if len(set(numeros)) != len(numeros):
            errs.append("Hay números de noticia repetidos.")
        if modo == "final" and sorted(numeros) != list(range(1, len(numeros) + 1)):
            errs.append("En los entregables finales las noticias deben numerarse de 1 a N sin saltos.")

    if modo == "final":
        r = d.get("resumen_ejecutivo") or []
        if not 3 <= len(r) <= 5:
            errs.append("resumen_ejecutivo debe tener entre 3 y 5 puntos (tiene %d)." % len(r))
        for x in r:
            if not x.get("titular"):
                errs.append("Un punto del resumen ejecutivo no tiene \"titular\".")
            for ref in x.get("noticias", []) or []:
                if ref not in numeros:
                    errs.append("El resumen ejecutivo cita la noticia %s, que no existe." % ref)
        if "descartadas" not in d:
            errs.append("Falta la lista \"descartadas\" (puede ir vacía): la necesita la regla anti-repetición.")
        P = d.get("precios")
        if not P:
            errs.append("Falta el bloque \"precios\".")
        else:
            if not RE_ISO.match(str(P.get("fecha_precios", ""))):
                errs.append("precios.fecha_precios debe ser AAAA-MM-DD.")
            for k in SECCIONES.get(tipo or meta.get("tipo"), []):
                sec = P.get(k)
                if not sec or not (sec.get("filas") or sec.get("spreads")):
                    errs.append("precios.%s no tiene datos (sección obligatoria en el tipo %s)." % (k, tipo or meta.get("tipo")))
                    continue
                for f in sec.get("filas", []) or []:
                    for c in ("precio", "d_sem", "p_sem", "d_mes", "p_mes"):
                        if f.get(c) is not None and not isinstance(f.get(c), str):
                            errs.append("precios.%s \"%s\": el campo %s debe ser texto tal como aparece en la imagen (o null)." % (k, f.get("nombre"), c))
            if not P.get("lectura"):
                errs.append("precios.lectura (2 a 3 líneas) es obligatoria.")
    # Anti-repetición determinista (URL y título); la comparación por hecho la hace Claude
    if historial:
        urls = {}
        tits = {}
        for etiqueta, f, n in historial:
            if n.get("url"):
                urls[norm_url(n["url"])] = (etiqueta, f, n)
            if n.get("titulo"):
                tits[norm_titulo(n["titulo"])] = (etiqueta, f, n)
        for n in ns:
            p = "Noticia #%s" % n.get("n")
            if norm_url(n.get("url")) in urls:
                e, f, _ = urls[norm_url(n["url"])]
                errs.append("%s REPITE una noticia %s en un reporte anterior (misma URL): %s" % (p, e, f))
                continue
            nt = norm_titulo(n.get("titulo", ""))
            es_act = str(n.get("titulo", "")).strip().lower().startswith("actualización:")
            if nt in tits and not es_act:
                e, f, _ = tits[nt]
                errs.append("%s REPITE una noticia %s en un reporte anterior (mismo título): %s" % (p, e, f))
            elif not es_act:
                for t2, (e, f, _) in tits.items():
                    if SequenceMatcher(None, nt, t2).ratio() >= 0.88:
                        avisos.append("%s se parece mucho a una noticia %s anterior (%s). Revisar si es el mismo hecho." % (p, e, f))
                        break
    else:
        avisos.append("No se indicó --historial: no se verificó la repetición contra reportes anteriores.")
    return errs, avisos


def main():
    ap = argparse.ArgumentParser(description="Genera y verifica entregables HTML de Four Bells.")
    ap.add_argument("--plantilla", required=True)
    ap.add_argument("--datos")
    ap.add_argument("--tipo", choices=["A", "B"])
    ap.add_argument("--salida")
    ap.add_argument("--historial", action="append", help="archivo(s) o patrón glob de reportes anteriores (repetible)")
    ap.add_argument("--verificar", help="solo verificar integridad de un HTML ya generado")
    ap.add_argument("--permitir-ejemplo", action="store_true", help="solo para pruebas con los datos de ejemplo")
    a = ap.parse_args()
    if a.plantilla in ("final", "seleccion"):
        a.plantilla = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plantilla_%s.html" % a.plantilla)

    plantilla = open(a.plantilla, encoding="utf-8").read()
    modo = "seleccion" if 'id="btnInstr"' in plantilla else "final"

    # La propia plantilla debe estar sana antes de usarla
    e0 = verificar_integridad(plantilla, plantilla)
    e0 = [x for x in e0 if "idéntico" not in x]
    if e0:
        print("LA PLANTILLA ESTÁ DAÑADA. No se genera nada:")
        for x in e0:
            print("  ✗", x)
        print("Pida al usuario que adjunte de nuevo la plantilla original.")
        sys.exit(1)

    if a.verificar:
        html = open(a.verificar, encoding="utf-8").read()
        errs = verificar_integridad(html, plantilla)
        if errs:
            print("VERIFICACIÓN FALLIDA — NO ENTREGAR ESTE ARCHIVO:")
            for x in errs:
                print("  ✗", x)
            sys.exit(1)
        print("VERIFICACIÓN OK: logo íntegro y oficial, fuentes Aspekta oficiales, diseño y código idénticos a la plantilla.")
        return

    if not (a.datos and a.salida):
        ap.error("--datos y --salida son obligatorios para generar.")
    try:
        d = json.load(open(a.datos, encoding="utf-8"))
    except Exception as e:
        print("✗ datos.json no es JSON válido:", e)
        sys.exit(1)
    if modo == "final":
        if not a.tipo:
            ap.error("--tipo A|B es obligatorio con la plantilla final.")
        d.setdefault("meta", {})["tipo"] = a.tipo
    else:
        d.setdefault("meta", {})["tipo"] = "SELECCION"

    historial = cargar_historial(a.historial)
    errs, avisos = validar_datos(d, modo, a.tipo, a.permitir_ejemplo, historial)
    if errs:
        print("ERRORES EN LOS DATOS — no se generó el archivo:")
        for x in errs:
            print("  ✗", x)
        for x in avisos:
            print("  !", x)
        sys.exit(1)

    bloque = json.dumps(d, ensure_ascii=False, indent=1).replace("<", "\\u003c")
    html = RE_BLOQUE.sub(lambda m: m.group(1) + bloque + m.group(3), plantilla, count=1)
    errs = verificar_integridad(html, plantilla)
    if errs:
        print("VERIFICACIÓN FALLIDA — no se guardó el archivo:")
        for x in errs:
            print("  ✗", x)
        sys.exit(1)
    with open(a.salida, "w", encoding="utf-8") as f:
        f.write(html)
    print("VERIFICACIÓN OK: %s" % a.salida)
    print("  logo íntegro y oficial · fuentes Aspekta oficiales · diseño y código idénticos a la plantilla")
    print("  %d noticias · tipo %s · %s" % (len(d.get("noticias", [])), d["meta"]["tipo"], "historial comparado (%d registros)" % len(historial) if historial else "SIN historial"))
    for x in avisos:
        print("  !", x)


if __name__ == "__main__":
    main()
